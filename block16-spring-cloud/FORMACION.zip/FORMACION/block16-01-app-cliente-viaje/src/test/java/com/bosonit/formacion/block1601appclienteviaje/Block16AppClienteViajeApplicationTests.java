package com.bosonit.formacion.block1601appclienteviaje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Block16AppClienteViajeApplicationTests {

	@Test
	void contextLoads() {
	}

}
