package com.bosonit.formacion.block1601appclienteviaje.start;

import com.bosonit.formacion.block1601appclienteviaje.passenger.domain.Passenger;
import com.bosonit.formacion.block1601appclienteviaje.passenger.repository.PassengerRepository;
import com.bosonit.formacion.block1601appclienteviaje.trip.domain.Trip;
import com.bosonit.formacion.block1601appclienteviaje.trip.repository.TripRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class StartComponent implements CommandLineRunner {

    @Autowired
    PassengerRepository passengerRepository;
    @Autowired
    TripRepository tripRepository;
    public static final String PASSENGER = "Passenger";
    public static final Integer AGE = 16;
    public static final int PHONE_NUMBER = 666555444;
    public static final String ORIGIN = "Origin";
    public static final String DESTINATION = "Destination";

    @Override
    public void run(String... args) throws Exception {

        List<Passenger> passengerList = new ArrayList<>();
        for (int i = 1; i < 6; i++) {
            Passenger passenger = new Passenger();
            passenger.setName(PASSENGER + i);
            passenger.setSurname(PASSENGER + i);
            passenger.setAge(AGE + i);
            passenger.setEmail(i + "@gmail.com");
            passenger.setPhoneNumber(PHONE_NUMBER);
            passengerRepository.save(passenger);
            passengerList.add(passenger);
        }

        Trip trip = new Trip();
        trip.setOrigin(ORIGIN + 1);
        trip.setDestination(DESTINATION + 2);
        trip.setDepartureDate("2023-10-10 20:00:00");
        trip.setArrivalDate("2023-10-25 07:30:00");
        trip.getPassengerList().add(passengerList.get(0));
        tripRepository.save(trip);

        Trip trip2 = new Trip();
        trip2.setOrigin(ORIGIN + 2);
        trip2.setDestination(DESTINATION + 2);
        trip2.setDepartureDate("2023-10-10 20:00:00");
        trip2.setArrivalDate("2023-10-25 07:30:00");
        trip2.getPassengerList().addAll(passengerList.subList(1, 4));
        tripRepository.save(trip2);
    }
}
