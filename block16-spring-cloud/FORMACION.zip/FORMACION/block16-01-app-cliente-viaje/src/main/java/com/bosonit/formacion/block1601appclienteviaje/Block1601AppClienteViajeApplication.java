package com.bosonit.formacion.block1601appclienteviaje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Block1601AppClienteViajeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Block1601AppClienteViajeApplication.class, args);
	}

}
