package com.bosonit.formacion.block1601appclienteviaje.passenger.controller.dto;

import com.bosonit.formacion.block1601appclienteviaje.passenger.domain.Passenger;

public class PassengerOutputDto {
    private int idPassenger;
    private String name;

    private String surname;

    private int age;

    private String email;

    private int phoneNumber;

    public PassengerOutputDto (Passenger passenger){
        this.idPassenger=passenger.getIdPassenger();
        this.name =passenger.getName();
        this.surname = passenger.getSurname();
        this.age = passenger.getAge();
        this.email = passenger.getEmail();
        this.phoneNumber = passenger.getPhoneNumber();
    }
}
